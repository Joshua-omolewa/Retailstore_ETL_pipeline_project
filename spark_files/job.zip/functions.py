# Author: Joshua Omolewa
from pyspark.sql import *
from pyspark.sql.types import StructType,StructField, StringType, IntegerType, DateType, DoubleType, BooleanType, TimestampType
from pyspark.sql.functions import current_timestamp
from sql_query import *





def read_files( spark, params, schma, file, inferschma = "false"):
    """"
    This function read the csv data files, infers the defined schemas 
    """
    df = spark.read.option('header','true'). \
    option("inferSchema", inferschma). \
    schema(schma). \
    csv(params[file])
    # df.show() #cheking dataframe is correct
    # df.printSchema() #checking schema is correct
    #print(df.schema.fields) #checking the schema fileld
    return df


def writing_parquet_files(params, output_folder_key, partion_column_key, df):
    """
    This function saves  the transform data in parquet to the
    output folder 
    """
    output_path_a = params[output_folder_key]
    partition_column_a = params[partion_column_key]
    df.write.option('header','true').partitionBy(partition_column_a).parquet(output_path_a)
    return df 

def empty_dataframe (spark, schma):
    """
    This function creates an empty dataframe and return the empty 
    dataframe with schema passed into it
    """
    df = spark.createDataFrame([], schma)
    return df



def sql_table(dataframe,tablename):
    """
    This funciton is required to create a view for sql queries
    """
    return dataframe.createOrReplaceTempView(tablename)


############## DEFAULT  SCHEMA FOR THE CSV FILES ###########

#PRODUCT SCHEMA

product_schema = StructType([
    StructField('PROD_KEY', IntegerType(), True), 
    StructField('PROD_NAME', StringType(), True),
    StructField('VOL', DoubleType(), True), 
    StructField('WGT', DoubleType(), True), 
    StructField('BRAND_NAME', StringType(), True),
    StructField('STATUS_CODE', IntegerType(), True), 
    StructField('STATUS_CODE_NAME', StringType(), True), 
    StructField('CATEGORY_KEY', IntegerType(), True), 
    StructField('CATEGORY_NAME', StringType(), True), 
    StructField('SUBCATEGORY_KEY', IntegerType(), True), 
    StructField('SUBCATEGORY_NAME', StringType(), True),
    ])





#STORE SCHEMA
store_schema = StructType([
    StructField('STORE_KEY', IntegerType(), True), 
    StructField('STORE_NUM', IntegerType(), True), 
    StructField('STORE_DESC', StringType(), True), 
    StructField('ADDR', StringType(), True), 
    StructField('CITY', StringType(), True), 
    StructField('REGION', StringType(), True), 
    StructField('CNTRY_CD', StringType(), True), 
    StructField('CNTRY_NM', StringType(), True), 
    StructField('POSTAL_ZIP_CD', StringType(), True), 
    StructField('PROV_STATE_DESC', StringType(), True), 
    StructField('PROV_STATE_CD', StringType(), True), 
    StructField('STORE_TYPE_CD', StringType(), True), 
    StructField('STORE_TYPE_DESC', StringType(), True), 
    StructField('FRNCHS_FLG', StringType(), True), 
    StructField('STORE_SIZE', StringType(), True), 
    StructField('MARKET_KEY', IntegerType(), True), 
    StructField('MARKET_NAME', StringType(), True), 
    StructField('SUBMARKET_KEY', IntegerType(), True), 
    StructField('SUBMARKET_NAME', StringType(), True), 
    StructField('LATITUDE', DoubleType(), True), 
    StructField('LONGITUDE', DoubleType(), True)
    ])




#CALENDAR SCHEMA
calendar_schema =  StructType([
    StructField('CAL_DT', DateType(), False), 
    StructField('CAL_TYPE_DESC', StringType(), True), 
    StructField('DAY_OF_WK_NUM', IntegerType(), True), 
    StructField('DAY_OF_WK_DESC', StringType(), True), 
    StructField('YR_NUM', IntegerType(), True), 
    StructField('WK_NUM', IntegerType(), True), 
    StructField('YR_WK_NUM', IntegerType(), True), 
    StructField('MNTH_NUM', IntegerType(), True), 
    StructField('YR_MNTH_NUM', IntegerType(), True), 
    StructField('QTR_NUM', IntegerType(), True), 
    StructField('YR_QTR_NUM', IntegerType(), True)
    ])




#SALES SCHEMA
sales_schema =  StructType([
    StructField('TRANS_ID', IntegerType(), True), 
    StructField('PROD_KEY', IntegerType(), True), 
    StructField('STORE_KEY', IntegerType(), True), 
    StructField('TRANS_DT', DateType(), True), 
    StructField('TRANS_TIME', IntegerType(), True), 
    StructField('SALES_QTY', DoubleType(), True), 
    StructField('SALES_PRICE', DoubleType(), True), 
    StructField('SALES_AMT', DoubleType(), True), 
    StructField('DISCOUNT', DoubleType(), True), 
    StructField('SALES_COST', DoubleType(), True), 
    StructField('SALES_MGRN', DoubleType(), True), 
    StructField('SHIP_COST', DoubleType(), True)
    ])

#INVENTORY SCHEMA
invetory_schema =  StructType([
    StructField('CAL_DT', DateType(), True), 
    StructField('STORE_KEY', IntegerType(), True), 
    StructField('PROD_KEY', IntegerType(), True), 
    StructField('INVENTORY_ON_HAND_QTY', DoubleType(), True), 
    StructField('INVENTORY_ON_ORDER_QTY', DoubleType(), True), 
    StructField('OUT_OF_STOCK_FLG', IntegerType(), True), 
    StructField('WASTE_QTY', DoubleType(), True), 
    StructField('PROMOTION_FLG', BooleanType(), True), 
    StructField('NEXT_DELIVERY_DT', DateType(), True)
    ])   



################ DIMENTION TABLES SCHEMA ##########

#CALENDAR DIM SCHEMA

calendar_dim_schema =  StructType([
    StructField('CAL_DT', DateType(), False), 
    StructField('CAL_TYPE_NAME', StringType(), True), 
    StructField('DAY_OF_WK_NUM', IntegerType(), True), 
    StructField('YEAR_NUM', IntegerType(), True), 
    StructField('WEEK_NUM', IntegerType(), True), 
    StructField('YEAR_WK_NUM', IntegerType(), True), 
    StructField('MONTH_NUM', IntegerType(), True), 
    StructField('YEAR_MNTH_NUM', IntegerType(), True), 
    StructField('QTR_NUM', IntegerType(), True), 
    StructField('YR_QTR_NUM', IntegerType(), True),
    ])



store_dim_schema = StructType([
    StructField('STORE_KEY', IntegerType(), True), 
    StructField('STORE_NAME', StringType(), True),
    StructField('STATUS_CODE', StringType(), True),
    StructField('STATUS_CD_NAME', StringType(), True),
    StructField('OPEN_DT', DateType(), True),
    StructField('CLOSE_DT', DateType(), True), 
    StructField('ADDR', StringType(), True), 
    StructField('CITY', StringType(), True), 
    StructField('REGION', StringType(), True), 
    StructField('CNTRY_CD', StringType(), True), 
    StructField('CNTRY_NM', StringType(), True), 
    StructField('POSTAL_ZIP_CD', StringType(), True), 
    StructField('PROV_NAME', StringType(), True), 
    StructField('PROV_CODE', StringType(), True), 
    StructField('MARKET_KEY', IntegerType(), True), 
    StructField('MARKET_NAME', StringType(), True), 
    StructField('SUBMARKET_KEY', IntegerType(), True), 
    StructField('SUBMARKET_NAME', StringType(), True), 
    StructField('LATITUDE', DoubleType(), True), 
    StructField('LONGITUDE', DoubleType(), True),
    ])
    



#PRODUCT DIM SCHEMA
product_dim_schema = StructType([
    StructField('PROD_KEY', IntegerType(), True), 
    StructField('PROD_NAME', StringType(), True),
    StructField('VOL', DoubleType(), True), 
    StructField('WGT', DoubleType(), True), 
    StructField('BRAND_NAME', StringType(), True),
    StructField('STATUS_CODE', IntegerType(), True), 
    StructField('STATUS_CODE_NAME', StringType(), True), 
    StructField('CATEGORY_KEY', IntegerType(), True), 
    StructField('CATEGORY_NAME', StringType(), True), 
    StructField('SUBCATEGORY_KEY', IntegerType(), True), 
    StructField('SUBCATEGORY_NAME', StringType(), True),
    ])




################ FACT TABLES SCHEMA ##########

#DAILY FACT TABLES SCHEMA
daily_sales_inv_schema =  StructType([
    StructField('CAL_DT', DateType(), True),
    StructField('STORE_KEY', IntegerType(), True), 
    StructField('PROD_KEY', IntegerType(), True), 
    StructField('SALES_QTY', DoubleType(), True), 
    StructField('SALES_PRICE', DoubleType(), True), 
    StructField('SALES_AMT', DoubleType(), True), 
    StructField('DISCOUNT', DoubleType(), True), 
    StructField('SALES_COST', DoubleType(), True), 
    StructField('SALES_MGRN', DoubleType(), True), 
    StructField('STOCK_ON_HAND_QTY', DoubleType(), True),
    StructField('ORDERED_STOCK_QTY', DoubleType(), True),
    StructField('OUT_OF_STOCK_FLG', IntegerType(), True),
    StructField('IN_STOCK_FLG', BooleanType(), True),
    StructField('LOW_STOCK_FLG', BooleanType(), True)
    ])



#WEEKLY FACT TABLES SCHEMA
weekly_sales_inv_schema =  StructType([
    StructField('CAL_DT', DateType(), True),
    StructField('YR_NUM', IntegerType(), True),
    StructField('WK_NUM', IntegerType(), True),
    StructField('STORE_KEY', IntegerType(), True), 
    StructField('PROD_KEY', IntegerType(), True), 
    StructField('WK_SALES_QTY', DoubleType(), True), 
    StructField('AVG_SALES_PRICE', DoubleType(), True), 
    StructField('AVG_SALES_AMT', DoubleType(), True), 
    StructField('WK_DISCOUNT', DoubleType(), True), 
    StructField('WK_SALES_COST', DoubleType(), True), 
    StructField('WK_SALES_MGRN', DoubleType(), True), 
    StructField('EOP_STOCK_ON_HAND_QTY', DoubleType(), True),
    StructField('EOP_ORDERED_STOCK_QTY', DoubleType(), True),
    StructField('OUT_OF_STOCK_TIMES', IntegerType(), True),
    StructField('IN_STOCK_TIMES', IntegerType(), True),
    StructField('LOW_STOCK_TIMES', IntegerType(), True),
    ])

