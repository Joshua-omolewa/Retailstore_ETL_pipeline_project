# #QUERY TO GET THE LAST DATE
# date_query = "SELECT MAX(cal_dt) FROM daily_fact"

# # date_query = "SELECT MAX(cal_dt) FROM calendar" #testing purposes

daily_sale_stg_query = """SELECT 
	trans_dt AS CAL_DT, 
	store_key AS STORE_KEY, 
	prod_key AS PROD_KEY, 
	sum(sales_qty ) AS SALES_QTY, 
	sum(sales_amt ) AS SALES_AMT, 
	avg(sales_price ) AS  SALES_PRICE, 
	sum(sales_cost) AS SALES_COST, 
	sum(sales_mgrn) AS SALES_MGRN, 
	avg(discount) AS DISCOUNT,
	sum(ship_cost) AS SHIP_COST 
FROM sales  
WHERE TRANS_DT>='1900-01-01' 
GROUP BY 1,2,3 
ORDER BY 1,2,3;"""


daily_inventory_query = """SELECT 
cal_dt   AS CAL_DT,
store_key   AS STORE_KEY,
prod_key   AS PROD_KEY,
inventory_on_hand_qty   AS STOCK_ON_HAND_QTY,
inventory_on_order_qty      AS ORDERED_STOCK,
out_of_stock_flg   AS OUT_OF_STOCK_FLG,
waste_qty   AS WASTE_QTY,
promotion_flg   AS PROMOTION_FLG,
next_delivery_dt   AS NEXT_DELIVERY_DT
FROM inventory
WHERE cal_dt>='1900-01-01'
"""



#WORKING CODE 2

daily_inventory_query1 = """
SELECT
	COALESCE(s.cal_dt,i.cal_dt) AS CAL_DT,
	COALESCE(s.store_key,i.store_key) AS STORE_KEY,
	COALESCE(s.prod_key,i.prod_key) AS PROD_KEY,
	nvl(s.sales_qty,0) AS SALES_QTY,
	nvl(s.sales_price,0) AS SALES_PRICE,
	nvl(s.sales_amt,0) AS SALES_AMT,
	nvl(s.discount,0) AS DISCOUNT,
	nvl(s.sales_cost,0) AS SALES_COST,
	nvl(s.sales_mgrn,0) AS SALES_MGRN,
	nvl(i.stock_on_hand_qty,0) AS STOCK_ON_HAND_QTY,
	nvl(i.ordered_stock,0) AS ORDERED_STOCK_QTY,
	nvl(i.out_of_stock_flg, 0) AS OUT_OF_STOCK_FLG,
	case when i.out_of_stock_flg=1 then 0 else 1 end as IN_STOCK_FLG,
	case when i.stock_on_hand_qty<s.sales_qty then 1 else 0 end as LOW_STOCK_FLG
FROM daily_sale_stg_df s
FULL OUTER JOIN daily_inventory_stg_df i USING (cal_dt, store_key, prod_key);
"""
weekly_fact_query = """
SELECT
	s.cal_dt as cal_dt,
	c.year_num as yr_num,
	c.week_num as wk_num,
	s.store_key,
	s.prod_key,
	sum(sales_qty) as wk_sales_qty,
	sum(sales_amt) as wk_sales_amt,
	avg(sales_price) as avg_sales_price,
	sum(case when c.day_of_wk_num=6 then s.stock_on_hand_qty else 0 end) as eop_stock_on_hand_qty,
	sum(case when c.day_of_wk_num=6 then s.ordered_stock_qty else 0 end) as eop_ordered_stock_qty,
	sum(sales_cost) as wk_sales_cost,

	ROUND(COUNT(case when c.day_of_wk_num BETWEEN 0 AND 6 AND OUT_OF_STOCK_FLG ==1 then 1 else NULL end)/7 * 100,2) as percentage,

	sum(OUT_OF_STOCK_FLG + LOW_STOCK_FLG) AS total_low_stock_impact,

	ROUND(sum(case when LOW_STOCK_FLG=1 then sales_amt - STOCK_ON_HAND_QTY else 0 end),2)  as potential_low_stock_impact,

	ROUND(sum(case when OUT_OF_STOCK_FLG=1 then sales_amt else 0 end),2)  as no_stock_impact,

	count(case when s.low_stock_flg=1 then 1  end) as low_stock_instance,
	count(case when s.out_of_stock_flg=1 then 1  end) as no_stock_instances,

	ROUND(sum(case when c.day_of_wk_num=6 then s.stock_on_hand_qty else 0 end)/sum(sales_qty),2) as how_many_wk_on_hand_can_supply

FROM final_daily_sale_stg_df s
JOIN calendar_dim c USING (cal_dt)
GROUP BY 1,2,3,4,5
ORDER BY 1,2,3,4,5
"""
